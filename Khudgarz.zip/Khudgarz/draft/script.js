const slides = [
    {
        title: "BBA (Bachelor of Business Administration)",
        fee: "Fees per semester: ₹100,000",
        description: "BBA provides students with a strong foundation in business management principles."
    },
    {
        title: "MBA (Master of Business Administration)",
        fee: "Fees per semester: ₹150,000",
        description: "MBA focuses on advanced management and leadership skills."
    },
    {
        title: "B.Tech (Bachelor of Technology)",
        fee: "Fees per semester: ₹120,000",
        description: "B.Tech program equips students with technical skills in various engineering fields."
    }
];

let currentSlide = 0;

const slideTitle = document.querySelector(".slide h2");
const slideFee = document.querySelector(".slide p:nth-child(2)");
const slideDescription = document.querySelector(".slide p:nth-child(3)");

function updateSlide() {
    slideTitle.innerText = slides[currentSlide].title;
    slideFee.innerText = slides[currentSlide].fee;
    slideDescription.innerText = slides[currentSlide].description;
}

document.querySelector(".prev").addEventListener("click", () => {
    currentSlide = (currentSlide > 0) ? currentSlide - 1 : slides.length - 1;
    updateSlide();
});

document.querySelector(".next").addEventListener("click", () => {
    currentSlide = (currentSlide < slides.length - 1) ? currentSlide + 1 : 0;
    updateSlide();
});

updateSlide();  // Initialize the first slide
